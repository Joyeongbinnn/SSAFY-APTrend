package com.ssafy.controller;

import com.ssafy.dto.ApartDto;
import com.ssafy.dto.HotAptDto;
import com.ssafy.service.ApartService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/apartments")
@RequiredArgsConstructor
public class ApartController {

    private final ApartService apartService;

    @GetMapping
    public ResponseEntity<List<ApartDto>> getAllApartments() {
        List<ApartDto> list = apartService.getAllApartments();
        return ResponseEntity.ok(list);
    }
    
    @GetMapping("/hot")
    public ResponseEntity<List<HotAptDto>> getHotApartments() {
        return ResponseEntity.ok(apartService.getHotApts());
    }

}
