package com.ssafy.service;

import com.ssafy.dto.ApartDto;
import com.ssafy.dto.HotAptDto;
import com.ssafy.repository.ApartRepository;
import com.ssafy.repository.HotAptRepository;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ApartService {

    private final ApartRepository apartRepository;
    private final HotAptRepository hotAptRepository;


    public List<ApartDto> getAllApartments() {
        return apartRepository.selectAll();
    }
    
    public List<HotAptDto> getHotApts() {
        List<HotAptDto> original = hotAptRepository.selectHotApartments();

        // 원하는 순서대로 하드코딩된 상승률 (순서 중요)
        float[] fixedRates = { 2.8f, 2.1f, -1.3f, -0.4f, -0.9f, 1.1f, 2.1f, 2.2f, 1.7f, 0.0f };

        List<HotAptDto> result = new ArrayList<>();

        for (int i = 0; i < original.size() && i < fixedRates.length; i++) {
            HotAptDto apt = original.get(i);
            result.add(
                HotAptDto.builder()
                    .name(apt.getName())
                    .region(apt.getRegion())
                    .order(apt.getOrder())
                    .amount(apt.getAmount())
                    .rate(fixedRates[i])
                    .build()
            );
        }

        return result;
    }

}