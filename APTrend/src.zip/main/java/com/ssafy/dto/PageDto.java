package com.ssafy.dto;

import lombok.Data;

@Data
public class PageDto {
	private int page;
}
