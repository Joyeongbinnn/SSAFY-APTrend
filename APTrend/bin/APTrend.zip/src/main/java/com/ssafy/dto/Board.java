package com.ssafy.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Board {
	private int id;
	private int userNumId;
	private String userId;
	private String title;
	private String createdAt;
	private String tag;
	private String summary;
	private String content;
}
