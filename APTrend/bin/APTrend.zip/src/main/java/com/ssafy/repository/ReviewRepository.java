package com.ssafy.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.ssafy.dto.Review;
import com.ssafy.dto.User;

@Repository
@Mapper
public interface ReviewRepository {
	int createReview(Review review);
	int deleteReview(int id, User user);
	int updateReview(Review review, User user);
	Review detailReview(int id);
	List<Review> reviewList(int page);
}
