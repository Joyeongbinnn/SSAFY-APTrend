package com.ssafy.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.dto.Board;
import com.ssafy.dto.Review;
import com.ssafy.dto.User;
import com.ssafy.repository.BoardRepository;
import com.ssafy.repository.ReviewRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ReviewService {
private final ReviewRepository repo;
	
	public int createReview(Review review) {
		return repo.createReview(review);
	}
	
	public int deleteReview(int id, User user) {
		return repo.deleteReview(id, user);
	}
	
	public int updateReview(Review review, User user) {
		return repo.updateReview(review, user);
	}
	
	public Review detailReview(int id) {
		return repo.detailReview(id);
	}
	
	public List<Review> reviewList(int page) {
		return repo.reviewList(page);
	}
}
