package com.ssafy.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.ssafy.dto.Board;
import com.ssafy.dto.User;

@Repository
@Mapper
public interface BoardRepository {
	int createBoard(Board board);
	int deleteBoard(int id, User user);
	int updateBoard(Board board, User user);
	Board detailBoard(int id);
	List<Board> boardList(int page);
}
