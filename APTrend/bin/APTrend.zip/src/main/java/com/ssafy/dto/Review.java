package com.ssafy.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Review {
	private int id;
	private int userNumId;
	private String userId;
	private String apartId;
	private String apartName;
	private String content;
	private float rate;
}
