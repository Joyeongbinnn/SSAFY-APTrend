package com.ssafy.repository;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.ssafy.dto.User;
import com.ssafy.dto.UserAuth;
import com.ssafy.dto.UserJoinUserAuth;

@Repository
@Mapper
public interface UserRepository {
	int createUser(User user);
	int createUserAuth(UserAuth user);
	int deleteUser(int id);
	int updateUser(User user);
	UserAuth findByLocalLoginId(String loginId);
	int findById(int id);
	User findByIdReturnUser(int id);
	User findByLoginId(String loginId);
	User findByEmail(String email);
	int findByEmailReturnInt(String email);
	UserJoinUserAuth findLocalDataByLoginId(String loginId);
}
