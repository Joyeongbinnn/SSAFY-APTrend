package com.ssafy.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.dto.Board;
import com.ssafy.dto.User;
import com.ssafy.repository.BoardRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class BoardService {
	private final BoardRepository repo;
	
	public int createBoard(Board board) {
		return repo.createBoard(board);
	}
	
	public int deleteBoard(int id, User user) {
		return repo.deleteBoard(id, user);
	}
	
	public int updateBoard(Board board, User user) {
		return repo.updateBoard(board, user);
	}
	
	public Board detailBoard(int id) {
		return repo.detailBoard(id);
	}
	
	public List<Board> boardList(int page) {
		return repo.boardList(page);
	}
}
